window.open=function(url){
	location.href=url;
};