Config({
	server:false,
	captcha:"//kptch1.wmid.com.ua/get.php"
});